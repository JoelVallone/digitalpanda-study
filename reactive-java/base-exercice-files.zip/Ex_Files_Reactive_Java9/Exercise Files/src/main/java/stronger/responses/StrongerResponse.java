package stronger.responses;

public class StrongerResponse {

	private Boolean stronger;
	
	public StrongerResponse() {
		
	}
	
	public StrongerResponse(Boolean stronger) {
		
		this.stronger = stronger;
	}

	public Boolean getStronger() {
		return stronger;
	}

	public void setStronger(Boolean stronger) {
		this.stronger = stronger;
	}
}
